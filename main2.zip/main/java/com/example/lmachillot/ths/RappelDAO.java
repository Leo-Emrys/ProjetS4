package com.example.lmachillot.ths;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class RappelDAO extends DAOBase {

    //DEBUG
    int minute=0;
    //////////////

    private Context pContext;
    public static String titrenotif="titre";
    public static String textenotif="texte";
    public static int idrappel;

    public static String nomtable = "rappel";
    public static String ID = "_id";
    public static String DATE = "daterappel";
    public static String OBJET = "objet";
    public static String HEURE = "heure_rappel";
    public static String DELAI = "delai";
    public static String IDTRAITEMENT= "_id_traitement";

    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    AlarmManager am;

    public RappelDAO(Context pContext) {
        super(pContext);
        this.pContext=pContext;

    }

    public long ajouterRappel(Rappel rappel) {
        java.sql.Date sqldate = new java.sql.Date(rappel.getDaterappel().getTime());

        ContentValues values = new ContentValues();
        values.put(OBJET, rappel.getObjet());
        values.put(DATE, sqldate.toString());
        values.put(HEURE, rappel.getHeure());
        values.put(DELAI, rappel.getDelai());
        values.put(IDTRAITEMENT, rappel.getIdtraitement());

        long id=mDb.insert(nomtable, null, values);
        if(id!=-1) {
            rappel.setId(id);
        }

        //créer une notif pour chaque rappel créé
        creationNotif(rappel);

        return id;
    }



    public long updateDateRappel(Rappel r) {
        java.sql.Date sqldate = new java.sql.Date(r.getDaterappel().getTime());
        ContentValues values = new ContentValues();
        values.put(DATE, sqldate.toString());

        long id = mDb.update(nomtable, values, String.format("%s = ?", ID), new String[]{r.getId()+""});

        //créer une notif pour chaque rappel créé
        creationNotif(r);
        return id;
    }

    public int getDelaiFrom(long idrappel) {
        int delai = -1;
        String req = "SELECT "+DELAI+" FROM "+nomtable+" WHERE "+ID+"="+idrappel;
        Cursor cursor = mDb.rawQuery(req, null);

        if (cursor!=null) {
            if (cursor.getCount()>0) {
                cursor.moveToFirst();
                delai = cursor.getInt(cursor.getColumnIndex(DELAI));
            }

            cursor.close();
        }

        return delai;
    }

    public int getHeureFrom(long idrappel) {
        int heure = -1;
        String req = "SELECT "+HEURE+" FROM "+nomtable+" WHERE "+ID+"="+idrappel;
        Cursor cursor = mDb.rawQuery(req, null);

        if (cursor!=null) {
            if (cursor.getCount()>0) {
                cursor.moveToFirst();
                heure = cursor.getInt(cursor.getColumnIndex(HEURE));
            }

            cursor.close();
        }

        return heure;
    }


    private void creationNotif(Rappel rappel) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(rappel.getDaterappel());

        int year=cal.get(Calendar.YEAR);
        int month=cal.get(Calendar.MONTH);
        int day=cal.get(Calendar.DAY_OF_MONTH);
        int heure = rappel.getHeure();
        int id = (int)rappel.getId();

        switch (rappel.getObjet()) {
            case "traitement" :
                titrenotif="Traitement à prendre !";
                textenotif="Cliquer pour acceder aux détails";
                break;
            case "ordonnance" :
                titrenotif="Alerte fin d'ordonnance";
                textenotif="Ordonnance à renouveller : cliquez pour voir les détails";
                break;
            case "stock" :
                titrenotif="Bientôt à cours de traitement !";
                textenotif="Cliquer pour acceder aux détails";
        }

        idrappel=id;

        am = (AlarmManager) pContext.getSystemService(Context.ALARM_SERVICE);
        ajouterAlarme((int)id, year, month, day, heure, minute);

        //test
        //ajouterAlarme((int)id, 2017, 2, 21, 16, 19);
    }

    private void ajouterAlarme(int id, int year, int month, int day, int hour, int minute)
    {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, hour, minute);

        Intent intent = new Intent(pContext, NotifReceiver.class);
        intent.putExtra("titrenotif", titrenotif);
        intent.putExtra("textenotif", textenotif);
        intent.putExtra("idrappel", idrappel);

        PendingIntent operation = PendingIntent.getBroadcast(pContext, id, intent, PendingIntent.FLAG_ONE_SHOT);
        // id --> identifiant de cette alarme particulière
        // utile pour cancel !
        am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), operation);


        //enregistrer dans table alarme
        Date date = cal.getTime();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());


        ContentValues values = new ContentValues();
        values.put("idalarme", id);
        values.put("datealarme", sqldate.toString());

        mDb.insert("alarme", null, values);

    }

    public boolean rappelExiste(Traitement t, int delai, int heure) {
        String req = "SELECT "+ID+" FROM "+nomtable+" WHERE "+IDTRAITEMENT+"="+t.getId()+" AND "+DELAI+"="+delai+" AND "+HEURE+"="+heure;
        Cursor cursor = mDb.rawQuery(req, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                return true;
            }
            cursor.close();
        }
        return false;
    }

    private List<Rappel> constrRappelFrom(Cursor cursor) {
        List<Rappel> liste = new ArrayList<>();
        while(cursor.moveToNext()) {
            long id=cursor.getLong(0);
            String objet = cursor.getString(cursor.getColumnIndex(OBJET));
            String datestr = cursor.getString(cursor.getColumnIndex(DATE));
            int heure = cursor.getInt(cursor.getColumnIndex(HEURE));
            int delai = cursor.getInt(cursor.getColumnIndex(DELAI));
            long idtraitement = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));

            format = new SimpleDateFormat("yyyy-MM-dd");
            Date date=null;

            try {
                date = format.parse(datestr);
            } catch (ParseException e) {
                Log.d("erreur format ", "premieredate traitementDAO //////////////////////////////////////");
                e.printStackTrace();
            }

            Rappel rappel = new Rappel(id, objet, date, heure, delai, idtraitement);
            liste.add(rappel);
        }

        return liste;
    }

    public List<Rappel> getRappels() {
        List<Rappel> liste = new ArrayList<>();
        String requete = "SELECT * FROM "+nomtable+" ORDER BY "+ID+" DESC LIMIT 50";

        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                liste = constrRappelFrom(cursor);
            }
            cursor.close();
        }

        return liste;
    }

    public long supprimerRappelsDuTraitement(long idtraitement) {
        //supprimmer alarmes associées
        List<Rappel> rappels = getRappelsFromId(idtraitement);
        for(Rappel r : rappels) {
            supprimeralarme(r.getId());
        }
        //supprimer rappels dans la table
        return mDb.delete(nomtable, String.format("%s = ?", IDTRAITEMENT), new String[] {idtraitement+""});
    }

    public long supprimerRappelsDepasses() {
        long nblignes;
        Date dateactuelle = new Date();
        java.sql.Date sqldate = new java.sql.Date(dateactuelle.getTime());

        //supprimer rappels concernés
        nblignes=mDb.delete(nomtable,  String.format("%s < ?", DATE), new String[]{sqldate.toString()});

        return nblignes;
    }

    //supprimer alarme
    private void supprimeralarme(long id) {
        //!!! supprimer alarme concernée, dont l'id est idrappel

        int idalarme = Integer.parseInt(id+"");

        am = (AlarmManager)pContext.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(pContext, NotifReceiver.class);
        PendingIntent sender = PendingIntent.getBroadcast(pContext, idalarme, intent, PendingIntent.FLAG_ONE_SHOT);
        am.cancel(sender);

        Log.d("~~~~~~~~~~~~~~~~~~~~~~", "ID ALARME SUPPRIMEE "+idalarme);

        //suppression dans table alarme
        mDb.delete("alarme", "idalarme = ?", new String[]{idrappel+""});
    }

    //supprimer un rappel
    public long supprimerRappelParId(long idrappel) {
        long suppr = mDb.delete(nomtable, String.format("%s = ?", ID),new String[]{idrappel+""});

        supprimeralarme(idrappel);

        return suppr;
    }



    //récupérer les rappels traitement du traitement t
    public List<Rappel> getRappelsFrom(Traitement t) {
        List<Rappel> liste = new ArrayList<>();
        String requete = "SELECT * FROM "+nomtable+
                         " WHERE "+IDTRAITEMENT+"="+t.getId()+" AND "+OBJET+"='traitement'";
        Cursor cursor = mDb.rawQuery(requete, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                liste = constrRappelFrom(cursor);
            }
            cursor.close();
        }


        return liste;
    }

    public List<Rappel> getRappelsFromId(long idtraitement) {
        List<Rappel> liste = new ArrayList<>();

        String req = "SELECT * FROM "+nomtable+" WHERE "+IDTRAITEMENT+" = "+idtraitement;
        Cursor cursor = mDb.rawQuery(req, null);

        if (cursor!=null) {
            if (cursor.getCount()>0) {
                liste = constrRappelFrom(cursor);
            }

            cursor.close();
        }

        return liste;
    }


    public Rappel getProchainRappelTraitement(Traitement t) {
        Rappel rappel = null;

        String requete = "SELECT * FROM "+nomtable+"  WHERE "+IDTRAITEMENT+"="+t.getId()+
                        " ORDER BY "+DATE+" ASC LIMIT 1 ";
        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                rappel=constrRappelFrom(cursor).get(0);
            }


            cursor.close();
        }


        return rappel;

    }


}

package com.example.lmachillot.ths;

/**
 * Created by lmachillot on 23/03/17.
 */

public class RappelPref {

    private long id;
    private int delai;
    private int heure;
    private Traitement traitement;

    public RappelPref(long id, int delai, int heure, Traitement traitement) {
        this.id = id;
        this.delai = delai;
        this.traitement = traitement;
        this.heure=heure;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getDelai() {
        return delai;
    }

    public void setDelai(int delai) {
        this.delai = delai;
    }

    public int getHeure() {
        return heure;
    }

    public void setHeure(int heure) {
        this.heure = heure;
    }

    public Traitement getTraitement() {
        return traitement;
    }

    public void setTraitement(Traitement traitement) {
        this.traitement = traitement;
    }

    @Override
    public String toString() {
        return "RappelPref{" +
                "id=" + id +
                ", delai=" + delai +
                ", traitement=" + traitement.getId() + " ("+traitement.getNom()+")"+
                '}';
    }
}

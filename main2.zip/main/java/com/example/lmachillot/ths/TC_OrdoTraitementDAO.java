package com.example.lmachillot.ths;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Leonard on 26/03/2017.
 */

public class TC_OrdoTraitementDAO extends DAOBase {

    public static String nomtable = "tc_ordo_traitement";
    public static String IDTRAITEMENT = "_id_traitement";
    public static String IDORDONNANCE = "_id_ordonnance";

    public TC_OrdoTraitementDAO(Context pContext) {
        super(pContext);
    }

    public List<Long> getIdTraitementsDeOrdo(long idordo) {
        List<Long> liste = new ArrayList<>();
        String requete = "SELECT "+IDTRAITEMENT+" FROM "+nomtable+" WHERE "+IDORDONNANCE+"="+idordo;
        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if (cursor.getCount()>0) {
                while(cursor.moveToNext()) {
                    long idt = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));
                    liste.add(idt);
                }
            }

            cursor.close();
        }


        return liste;
    }
}

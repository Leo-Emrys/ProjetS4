package com.example.lmachillot.ths;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EditerTraitementActivity extends MenuActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editer_traitement);
    }
}

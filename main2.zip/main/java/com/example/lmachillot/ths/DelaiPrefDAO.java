package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 23/03/17.
 */

public class DelaiPrefDAO extends DAOBase {

    public static String nomtable = "rappelpref";
    public static String ID = "_id";
    public static String DELAI = "nbjours";
    public static String IDTRAITEMENT = "_id_traitement";
    public static String HEURE = "heure";



    public DelaiPrefDAO(Context pContext) {
        super(pContext);
    }

    public long ajouterDelaiPref(DelaiPref dp) {
        ContentValues values = new ContentValues();
        values.put(DELAI, dp.getDelai());
        values.put(IDTRAITEMENT, dp.getTraitement().getId());
        values.put(HEURE, dp.getHeure());
        long id = mDb.insert(nomtable, null, values);
        dp.setId(id);
        return id;
    }

    public DelaiPref getDelaiPrefFrom(Traitement t, int delai, int heure) {
        DelaiPref dp = null;
        String req = "SELECT * FROM "+nomtable+" WHERE "+IDTRAITEMENT+"="+t.getId()+" AND "+DELAI+"="+delai+" AND "+HEURE+" = "+heure;
        Cursor cursor = mDb.rawQuery(req, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.moveToFirst();
                long id = cursor.getLong(0);
                dp = new DelaiPref(id, delai, heure, t);
            }


            cursor.close();
        }

        return dp;
    }

    public long supprimerDelaiPref(DelaiPref dp) {
        return mDb.delete(nomtable, String.format("%s = ?", ID), new String[] {dp.getId()+""});
    }


    public List<String> getDelaiPrefStr(){
        List<String> liste = new ArrayList<>();

        String requete = "SELECT * FROM "+nomtable+
                        " INNER JOIN "+TraitementDAO.nomtable+
                        " ON "+IDTRAITEMENT+"="+TraitementDAO.nomtable+"."+TraitementDAO.ID;

        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while (cursor.moveToNext()) {
                    long iddp = cursor.getLong(0);
                    int delai = cursor.getInt(cursor.getColumnIndex(DELAI));
                    long idtraitement = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));
                    int heure = cursor.getInt(cursor.getColumnIndex(HEURE));

                    liste.add(" ID : "+iddp+" / DELAI : "+delai+" / HEURE : "+heure+" / idtraitement : "+idtraitement);

                }
            }

            cursor.close();
        }

        return liste;
    }

    public List<DelaiPref> getDelaiPrefFrom(Traitement traitement) {
        List<DelaiPref> liste = new ArrayList<>();

        String requete = "SELECT * FROM "+nomtable+" WHERE "+IDTRAITEMENT+"="+traitement.getId();
        Cursor cursor = mDb.rawQuery(requete, null);

        if (cursor!=null) {
            if (cursor.getCount()>0) {
                while(cursor.moveToNext()) {
                    long iddp = cursor.getLong(0);
                    int delai = cursor.getInt(cursor.getColumnIndex(DELAI));
                    int heure = cursor.getInt(cursor.getColumnIndex(HEURE));

                    DelaiPref dp = new DelaiPref(iddp, delai, heure, traitement);
                    liste.add(dp);

                }
            }

            cursor.close();
        }

        return liste;
    }

}

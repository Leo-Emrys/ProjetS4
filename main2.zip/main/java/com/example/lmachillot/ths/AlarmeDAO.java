package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 22/03/17.
 */

public class AlarmeDAO extends DAOBase {

    public static String nomtable = "alarme";
    public static String ID = "_id";
    public static String DATE = "datealarme";
    public static String IDALARME = "idalarme";

    public AlarmeDAO(Context pContext) {
        super(pContext);
    }

    public long ajouterAlarme(Alarme alarme) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(alarme.getDate());
        Date date = cal.getTime();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());

        ContentValues values = new ContentValues();
        values.put("idalarme", alarme.getIdalarme());
        values.put("datealarme", sqldate.toString());
        long insert = mDb.insert("alarme", null, values);

        alarme.setId(insert);

        return insert;
    }


    public List<String> getAlarmes() {
        List<String> liste = new ArrayList<>();

        String req = "SELECT * FROM "+nomtable;
        Cursor cursor = mDb.rawQuery(req, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(0);
                    String datestr = cursor.getString(cursor.getColumnIndex(DATE));
                    long idalarme = cursor.getLong(cursor.getColumnIndex(IDALARME));

                    liste.add("id : "+id+" / idalarme : "+idalarme+" / date : "+datestr);
                }
            }
            cursor.close();
        }

        return liste;
    }

    public long supprimerAlarmeParId(long idalarme) {
        return mDb.delete(nomtable, String.format("%s = ?", IDALARME), new String[]{idalarme+""});
    }

    public long supprimerAlarmes() {
        return  mDb.delete(nomtable, null, null);
    }
}

package com.example.lmachillot.ths;

import android.content.Context;

/**
 * Created by Leonard on 26/03/2017.
 */

public class OrdonnanceDAO extends DAOBase {

    public String nomtable = "ordonnance";
    public String ID = "_id";
    public String DATE = "date_ordo";
    public String DUREE = "duree_ordo";

    public OrdonnanceDAO(Context pContext) {
        super(pContext);
    }



}

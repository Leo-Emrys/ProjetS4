package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by Leonard on 26/03/2017.
 */

public class Alarme {

    private long id;
    private Date date;
    private long idalarme;

    public Alarme(long id, Date date, long idalarme) {
        this.id = id;
        this.date = date;
        this.idalarme = idalarme;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getIdalarme() {
        return idalarme;
    }

    public void setIdalarme(long idalarme) {
        this.idalarme = idalarme;
    }

    @Override
    public String toString() {
        return "Alarme{" +
                "id=" + id +
                ", date=" + date +
                ", idalarme=" + idalarme +
                '}';
    }
}

package com.example.lmachillot.ths;

import android.content.Context;

/**
 * Created by Leonard on 26/03/2017.
 */

public class StockDAO extends DAOBase {

    public static String nomtable = "stock";
    public static String ID = "_id";
    public static String DATE = "datestock";
    public static String DUREE = "duree_stock";

    public StockDAO(Context pContext) {
        super(pContext);
    }
}

package com.example.lmachillot.ths;

/**
 * Created by lmachillot on 13/03/17.
 */

public enum Hormone {
    testostérone, œstrogènes, anti_androgènes, progestérone;

}

package com.example.lmachillot.ths;

/**
 * Created by lmachillot on 13/03/17.
 */

public enum Type {

    injection("injection"), gel("application"), crème("application"), comprimé("prise"), patch("renouvellement"), implant("renouvellement");


    private final String denomination;

    Type(String denomination) {
        this.denomination=denomination;
    }

    public String getDenom() {
        return this.denomination;
    }
}

package com.example.lmachillot.ths;

import android.content.Intent;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class ProchaineDateActivity extends AppCompatActivity {

    public static String IDTRAITEMENT = "-1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prochaine_date);

        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();

        List<Traitement> liste = tdao.getTraitements();

        tdao.close();



        // afficher traitements dynamiquement


        String[] columns = new String[] { "_id", "col1", "col2", "col3", "col4" };
        MatrixCursor matrixCursor= new MatrixCursor(columns);
        startManagingCursor(matrixCursor);

        int compteur = 1;
        for(Traitement t : liste ) {



            Log.d("liste : ", t.toString());


            //Recuperer intitule

            String accord="";
            if(t.getType().getAccord()=='f') {
                accord="e";
            }

            String nomtraitement = t.getNom() + " : ";

            String intitule = "prochain"+accord+" "+t.getType().getDenom()+" le ";

            //récupérer date

            Date date = t.getDate_renouvellement();
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime(date);
            int dd = cal.get(Calendar.DAY_OF_WEEK);
            String nomjour = getResources().getStringArray(R.array.jours)[dd-1];
            int numjour = cal.get ( Calendar.DAY_OF_MONTH );

            int nummois=cal.get(Calendar.MONTH);
            String mois  = getResources().getStringArray(R.array.mois)[nummois];
            int annee = cal.get(Calendar.YEAR);

            Log.d("date : ", t.getDate_renouvellement().toString());

            String datestr=nomjour+" "+numjour+" "+mois+" "+annee;



            matrixCursor.addRow(new Object[] { compteur, t.getId()+"", nomtraitement, intitule, datestr });
            compteur++;




/*
            final TextView textViewInt = (TextView) findViewById(R.id.intprochainedate);
            textViewInt.setText(intitule);
            final TextView textViewDate = (TextView) findViewById(R.id.date);
            textViewDate.setText(datestr);
            */
        }

        String[] from = new String[] {"col1", "col2", "col3", "col4"};

        int[] to = new int[] { R.id.idtraitementnv, R.id.intnomtraitement, R.id.intprochainedate, R.id.prochdate};


        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.ligneprochdate, matrixCursor, from, to, 0);

        ListView lv = (ListView) findViewById(R.id.list);
        lv.setAdapter(adapter);




                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> list, View view, int position, long id) {
                Log.i("+++++++++++++++", "onListItemClick: " + position);

            }

        });



    }


    public void nouvelledate(View view) {

        LinearLayout parent = (LinearLayout) view.getParent();
        TextView child = (TextView) parent.getChildAt(0);
        Log.d("++++++++++++++++++", child.getText().toString());
        IDTRAITEMENT = child.getText().toString();

        Intent intent = new Intent(ProchaineDateActivity.this, NouvelleDateActivity.class);
        finish();
        intent.putExtra(IDTRAITEMENT, IDTRAITEMENT);
        startActivityForResult(intent, 0);

    }


}

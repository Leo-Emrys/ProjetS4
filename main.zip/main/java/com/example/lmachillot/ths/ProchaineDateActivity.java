package com.example.lmachillot.ths;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

public class ProchaineDateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prochaine_date);

        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();

        List<Traitement> liste = tdao.getTraitements();

        tdao.close();

        for(Traitement t : liste) {
            Log.d("liste : ", t.toString());
        }

        // juste le premier pour commencer --> afficher liste le cas échéant = à faire

        Traitement t = liste.get(0);

        //Recuperer intitule

        String accord="";
        if(t.getType().getAccord()=='f') {
            accord="e";
        }

        String intitule = t.getNom()+" : "+"prochain"+accord+" "+t.getType().getDenom()+" le ";

        //récupérer date

        Date date = t.getDate_renouvellement();
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        int dd = cal.get(Calendar.DAY_OF_WEEK);
        String nomjour = getResources().getStringArray(R.array.jours)[dd-1];
        int numjour = cal.get ( Calendar.DAY_OF_MONTH );

        int nummois=cal.get(Calendar.MONTH);
        String mois  = getResources().getStringArray(R.array.mois)[nummois];
        int annee = cal.get(Calendar.YEAR);

        Log.d("date : ", t.getDate_renouvellement().toString());

        String datestr=nomjour+" "+numjour+" "+mois+" "+annee;

        final TextView textViewInt = (TextView) findViewById(R.id.intprochainedate);
        textViewInt.setText(intitule);
        final TextView textViewDate = (TextView) findViewById(R.id.date);
        textViewDate.setText(datestr);
    }
}

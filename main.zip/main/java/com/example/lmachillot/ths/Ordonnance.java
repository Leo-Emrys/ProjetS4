package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by lmachillot on 13/03/17.
 */

public class Ordonnance {

    private long id;
    private Date dateordo;
    private int duree;
}

package com.example.lmachillot.ths;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by lmachillot on 13/03/17.
 */

public class Prise {

    private Date dateprise;
    private Traitement traitement;
    private Zone zone;

    public Prise(Date dateprise, Traitement traitement, Zone zone) {
        this.dateprise = dateprise;
        this.traitement = traitement;
        this.zone=zone;

        // changer la date de renouvellement du traitement en fonction de la date de la prise et de la fréquence du traitement
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(this.dateprise);
        cal.add(Calendar.DATE, traitement.getFrequence());
        traitement.setDate_renouvellement(cal.getTime());


    }


    public Date getDateprise() {
        return dateprise;
    }

    public void setDateprise(Date dateprise) {
        this.dateprise = dateprise;
    }

    public Traitement getTraitement() {
        return traitement;
    }

    public void setTraitement(Traitement traitement) {
        this.traitement = traitement;
    }
}

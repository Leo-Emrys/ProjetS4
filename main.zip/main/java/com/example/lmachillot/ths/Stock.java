package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by Leonard on 26/03/2017.
 */

public class Stock {
    private long id;
    private Date datestock;
    private int duree;

    public Stock(long id, Date datestock, int duree) {
        this.id = id;
        this.datestock = datestock;
        this.duree = duree;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDatestock() {
        return datestock;
    }

    public void setDatestock(Date datestock) {
        this.datestock = datestock;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    @Override
    public String toString() {
        return "Stock{" +
                "id=" + id +
                ", datestock=" + datestock +
                ", duree=" + duree +
                '}';
    }
}

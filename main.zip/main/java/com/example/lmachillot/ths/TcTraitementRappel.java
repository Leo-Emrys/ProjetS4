package com.example.lmachillot.ths;

/**
 * Created by lmachillot on 21/03/17.
 */

public class TcTraitementRappel {

    private Traitement traitement;
    private Rappel rappel;

    public TcTraitementRappel(Traitement traitement, Rappel rappel) {
        this.traitement = traitement;
        this.rappel = rappel;
    }

    public Traitement getTraitement() {
        return traitement;
    }

    public void setTraitement(Traitement traitement) {
        this.traitement = traitement;
    }

    public Rappel getRappel() {
        return rappel;
    }

    public void setRappel(Rappel rappel) {
        this.rappel = rappel;
    }

    @Override
    public String toString() {
        return "TcTraitementRappel{" +
                "traitement=" + traitement +
                ", rappel=" + rappel +
                '}';
    }
}

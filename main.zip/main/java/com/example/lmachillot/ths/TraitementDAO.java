package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import java.lang.reflect.Array;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lmachillot on 13/03/17.
 */

public class TraitementDAO extends DAOBase {

    public String nomtable = "traitement";

    public static String ID = "_id";
    public static String NOM = "nomtraitement";
    public static String HORMONE = "hormone";
    public static String FREQUENCE = "frequence";
    public static String PREMIERE_PRISE = "premiere_prise";
    public static String DATE_RENOUVELLEMENT = "date_renouvellement";
    public static String DUREE_STOCK = "duree_stock";
    public static String TYPE = "_id_type";
    public static String DOSAGE = "dosage";

    public TraitementDAO(Context pContext) {
        super(pContext);


    }

    public long ajouterTraitement(Traitement t) {

        // récupérer clé du type voulu
        String req = "SELECT _id FROM type WHERE intituletype = '"+t.getType().name()+"'";
        Cursor cursor = mDb.rawQuery(req, null);

        cursor.moveToFirst();
        int idtype = cursor.getInt(0);

        //conversion des dates en format sql

        java.sql.Date sqlDatePrem = new java.sql.Date(t.getPremiereprise().getTime());
        //Log.d("sqldate première prise", " ////////////////////////////// "+sqlDatePrem+"");

        java.sql.Date sqlDateSuiv = new java.sql.Date(t.getDate_renouvellement().getTime());
        //Log.d("sqldate prochaine prise", " ////////////////////////////// "+sqlDateSuiv+"");

        //insertion
        ContentValues value = new ContentValues();
        value.put(NOM, t.getNom());
        value.put(HORMONE, t.getHormone().toString());
        value.put(FREQUENCE, t.getFrequence());
        value.put(PREMIERE_PRISE, sqlDatePrem.toString());
        value.put(DATE_RENOUVELLEMENT, sqlDateSuiv.toString());
        value.put(DUREE_STOCK, t.getDurée_stock());
        value.put(DOSAGE, t.getDosage());
        value.put(TYPE, idtype);

        //Log.d("value content", " :::::::::::::::::::::::::::::::"+value+"");


        long id = mDb.insert(nomtable, null, value);

        Log.d("ID CREE", " :::::::::::::::::::::::::::::::"+id+"");

        //mettre ajout id du Traitement dans modèle
        t.setId(id);

/*
        String requete = "INSERT INTO "+nomtable+" VALUES (null, '"+t.getNom() +"', '"+t.getHormone().toString()+"', "+t.getFrequence()+", '"+sqlDatePrem+"', '"+sqlDateSuiv+"', "+t.getDurée_stock()+", "+idtype+")";
        mDb.execSQL(requete);
*/


        return id;
    }


    public void majDateRenouvellement(Traitement t) {
        String req = "UPDATE "+DATE_RENOUVELLEMENT+" FROM "+nomtable+" WHERE "+ID+"="+t.getId();
        mDb.execSQL(req);
    }


    public ArrayList<Traitement> getTraitements() {
        ArrayList<Traitement> liste = new ArrayList<Traitement>();

        String requete = "SELECT traitement."+ID+", "+NOM+", "+HORMONE+", "+FREQUENCE+", "+PREMIERE_PRISE+", "+DATE_RENOUVELLEMENT+", "+DUREE_STOCK+", "+DOSAGE+", "
                                    +"type._id, intituletype, denomination "+
                        "FROM traitement INNER JOIN type ON "+TYPE+"=type._id";

        Cursor cursor = mDb.rawQuery(requete, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                cursor.moveToFirst();
                while(!cursor.isLast()) {
                    //récupérer type
                    String typestr = cursor.getString(cursor.getColumnIndex("intituletype"));
                    Type type=null;
                    for(Type t : Type.values()) {
                        if(t.name().equals(typestr)) {
                            type=t;
                        }
                    }
                    if(type==null) {
                        Log.d("------------------", "type inconnu !!");
                    }

                    //récupérer id
                    Long idtraitement=cursor.getLong(cursor.getColumnIndex(ID));
                    //nom
                    String nom = cursor.getString(cursor.getColumnIndex(NOM));
                    //hormone
                    String hormonestr = cursor.getString(cursor.getColumnIndex(HORMONE));
                    Hormone hormone=null;
                    for(Hormone h : Hormone.values()) {
                        if (h.name().equals(hormonestr)) {
                            hormone = h;
                        }
                    }

                    //frequence
                    int frequence = cursor.getInt(cursor.getColumnIndex(FREQUENCE));

                    //première date
                    String premieredatestr = cursor.getString(cursor.getColumnIndex(PREMIERE_PRISE));

                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date premieredate=null;
                    try {
                        premieredate = format.parse(premieredatestr);
                        Log.d("format prem date", "********************  "+premieredate);
                    } catch (ParseException e) {
                        Log.d("erreur format", "//////////////////////////////////////");
                        e.printStackTrace();
                    }

                    //date renouvellement
                    String daterenouvstr = cursor.getString(cursor.getColumnIndex(DATE_RENOUVELLEMENT));
                    Date daterenouv=null;
                    try {
                        daterenouv = format.parse(daterenouvstr);
                        Log.d("format date renouv", "********************  "+daterenouv);
                    } catch (ParseException e) {
                        Log.d("erreur format", "//////////////////////////////////////");
                        e.printStackTrace();
                    }

                    //stock
                    int stock = cursor.getInt(cursor.getColumnIndex(DUREE_STOCK));
                    float dosage = cursor.getFloat(cursor.getColumnIndex(DOSAGE));


                    Traitement trtmt = new Traitement(idtraitement, nom, hormone, frequence, premieredate, daterenouv, stock, dosage, type);
                    liste.add(trtmt);

                    cursor.moveToNext();

                }

                //dernière entrée
                //récupérer type
                String typestr = cursor.getString(cursor.getColumnIndex("intituletype"));
                Type type=null;
                for(Type t : Type.values()) {
                    if(t.name().equals(typestr)) {
                        type=t;
                    }
                }
                if(type==null) {
                    Log.d("------------------", "type inconnu !!");
                }

                //récupérer id
                Long idtraitement=cursor.getLong(cursor.getColumnIndex(ID));
                //nom
                String nom = cursor.getString(cursor.getColumnIndex(NOM));
                //hormone
                String hormonestr = cursor.getString(cursor.getColumnIndex(HORMONE));
                Hormone hormone=null;
                for(Hormone h : Hormone.values()) {
                    if (h.name().equals(hormonestr)) {
                        hormone = h;
                    }
                }

                //frequence
                int frequence = cursor.getInt(cursor.getColumnIndex(FREQUENCE));

                //première date
                String premieredatestr = cursor.getString(cursor.getColumnIndex(PREMIERE_PRISE));

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                Date premieredate=null;
                try {
                    premieredate = format.parse(premieredatestr);
                    Log.d("format prem date", "********************  "+premieredate);
                } catch (ParseException e) {
                    Log.d("erreur format", "//////////////////////////////////////");
                    e.printStackTrace();
                }

                //date renouvellement
                String daterenouvstr = cursor.getString(cursor.getColumnIndex(DATE_RENOUVELLEMENT));
                Date daterenouv=null;
                try {
                    daterenouv = format.parse(daterenouvstr);
                    Log.d("format date renouv", "********************  "+daterenouv);
                } catch (ParseException e) {
                    Log.d("erreur format", "//////////////////////////////////////");
                    e.printStackTrace();
                }

                //stock
                int stock = cursor.getInt(cursor.getColumnIndex(DUREE_STOCK));
                float dosage = cursor.getFloat(cursor.getColumnIndex(DOSAGE));


                Traitement trtmt = new Traitement(idtraitement, nom, hormone, frequence, premieredate, daterenouv, stock, dosage, type);
                liste.add(trtmt);


            } else {
                Log.d("----", "+++++++++++++++++++++++++pas de lignes ?????????????????");

            }
        } else {
            Log.d("--------", "----------------problème");
        }
        cursor.close();

        return liste;
    }


    //DEBUG
    public void supprimerTousTraitements() {
        mDb.delete(nomtable, null, null);
    }


}

package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class RappelDAO extends DAOBase {

    public static String nomtable = "rappel";
    public static String ID = "_id";
    public static String DATE = "daterappel";
    public static String MODE = "mode";

    public RappelDAO(Context pContext) {
        super(pContext);
    }

    public long ajouterRappel(Rappel rappel) {
        java.sql.Date sqldate = new java.sql.Date(rappel.getDaterappel().getTime());

        ContentValues values = new ContentValues();
        values.put(MODE, rappel.getMode());
        values.put(DATE, sqldate.toString());

        long id=mDb.insert(nomtable, null, values);
        if(id!=-1) {
            rappel.setId(id);
        }

        return id;
    }

    public List<Rappel> getRappels() {
        List<Rappel> liste = new ArrayList<>();
        String requete = "SELECT * FROM "+nomtable+" ORDER BY "+ID+" DESC LIMIT 50";

        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while(cursor.moveToNext()) {
                    long id=cursor.getLong(0);
                    String mode = cursor.getString(cursor.getColumnIndex(MODE));
                    String datestr = cursor.getString(cursor.getColumnIndex(DATE));

                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date date=null;

                    try {
                        date = format.parse(datestr);
                    } catch (ParseException e) {
                        Log.d("erreur format premieredate traitementDAO", "//////////////////////////////////////");
                        e.printStackTrace();
                    }

                    Rappel rappel = new Rappel(id, date, mode);
                    liste.add(rappel);
                }
            }
        }

        return liste;
    }


}

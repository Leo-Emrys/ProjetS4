package com.example.lmachillot.ths;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class RappelDAO extends DAOBase {

    private Context pContext;
    public static String titrenotif;
    public static String textenotif;
    public static int idrappel;

    public static String nomtable = "rappel";
    public static String ID = "_id";
    public static String DATE = "daterappel";
    public static String OBJET = "objet";
    public static String HEURE = "heure_rappel";
    public static String DELAI = "delai";

    AlarmManager am;

    public RappelDAO(Context pContext) {
        super(pContext);
        this.pContext=pContext;

    }

    public long ajouterRappel(Rappel rappel) {
        java.sql.Date sqldate = new java.sql.Date(rappel.getDaterappel().getTime());

        ContentValues values = new ContentValues();
        values.put(OBJET, rappel.getObjet());
        values.put(DATE, sqldate.toString());
        values.put(HEURE, rappel.getHeure());
        values.put(DELAI, rappel.getDelai());

        long id=mDb.insert(nomtable, null, values);
        if(id!=-1) {
            rappel.setId(id);
        }

        //créer une notif pour chaque rappel créé
        creationNotif(rappel);

        return id;
    }



    public long updateDateRappel(Rappel r) {
        java.sql.Date sqldate = new java.sql.Date(r.getDaterappel().getTime());
        ContentValues values = new ContentValues();
        values.put(DATE, sqldate.toString());

        long id = mDb.update(nomtable, values, String.format("%s = ?", ID), new String[]{r.getId()+""});

        //créer une notif pour chaque rappel créé
        creationNotif(r);
        return id;
    }

    private void creationNotif(Rappel rappel) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(rappel.getDaterappel());

        int year=cal.get(Calendar.YEAR);
        int month=cal.get(Calendar.MONTH);
        int day=cal.get(Calendar.DAY_OF_MONTH);
        int heure = rappel.getHeure();
        int id = (int)rappel.getId();


        titrenotif="Traitement à prendre !";
        textenotif="cliquez ici";
        idrappel=id;

        am = (AlarmManager) pContext.getSystemService(Context.ALARM_SERVICE);
        ajouterAlarme((int)id, year, month, day, heure, 0);

        //test
        //ajouterAlarme((int)id, 2017, 2, 21, 16, 19);
    }

    private void ajouterAlarme(int id, int year, int month, int day, int hour, int minute)
    {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, hour, minute);

        Intent intent = new Intent(pContext, NotifReceiver.class);
        intent.putExtra("titrenotif", titrenotif);
        intent.putExtra("textenotif", textenotif);
        intent.putExtra("idrappel", idrappel);

        PendingIntent operation = PendingIntent.getBroadcast(pContext, id, intent, PendingIntent.FLAG_ONE_SHOT);
        am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), operation);
    }

    public List<Rappel> getRappels() {
        List<Rappel> liste = new ArrayList<>();
        String requete = "SELECT * FROM "+nomtable+" ORDER BY "+ID+" DESC LIMIT 50";

        Cursor cursor = mDb.rawQuery(requete, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while(cursor.moveToNext()) {
                    long id=cursor.getLong(0);
                    String objet = cursor.getString(cursor.getColumnIndex(OBJET));
                    String datestr = cursor.getString(cursor.getColumnIndex(DATE));
                    int heure = cursor.getInt(cursor.getColumnIndex(HEURE));
                    int delai = cursor.getInt(cursor.getColumnIndex(DELAI));

                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date date=null;

                    try {
                        date = format.parse(datestr);
                    } catch (ParseException e) {
                        Log.d("erreur format premieredate traitementDAO", "//////////////////////////////////////");
                        e.printStackTrace();
                    }

                    Rappel rappel = new Rappel(id, objet, date, heure, delai);
                    liste.add(rappel);
                }
            }
            cursor.close();
        }

        return liste;
    }

    public long supprimerRappelsDepasses() {
        long nblignes;
        Date dateactuelle = new Date();
        java.sql.Date sqldate = new java.sql.Date(dateactuelle.getTime());

        //supprimer lignes associées dans table croisée traitement/rappel
        String req = "SELECT "+ID+" FROM "+nomtable+" WHERE "+DATE+"<"+sqldate;
        Cursor cursor = mDb.rawQuery(req, null);
        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while (cursor.moveToNext()) {
                    mDb.delete(TC_TraitementRappelDAO.nomtable, String.format("%s = ?", TC_TraitementRappelDAO.IDRAPPEL), new String[]{cursor.getLong(0)+""});
                }
            }
            cursor.close();
        }

        //supprimer rappels concernés
        nblignes=mDb.delete(nomtable,  String.format("%s < ?", DATE), new String[]{sqldate.toString()});


        return nblignes;
    }


}

package com.example.lmachillot.ths;

/**
 * Created by lmachillot on 16/03/17.
 */

public class TC_TraitementRappel {

    private long idtraitement;
    private long idrappel;

    public TC_TraitementRappel(long idtraitement, long idrappel) {
        this.idtraitement=idtraitement;
        this.idrappel=idrappel;
    }


    public long getIdtraitement() {
        return idtraitement;
    }

    public void setIdtraitement(long idtraitement) {
        this.idtraitement = idtraitement;
    }

    public long getIdrappel() {
        return idrappel;
    }

    public void setIdrappel(long idrappel) {
        this.idrappel = idrappel;
    }

    @Override
    public String toString() {
        return "TC_TraitementRappel{" +
                "idtraitement=" + idtraitement +
                ", idrappel=" + idrappel +
                '}';
    }
}

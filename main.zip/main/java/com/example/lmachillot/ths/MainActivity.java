package com.example.lmachillot.ths;


import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class MainActivity extends MenuActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        boolean traitement = tdao.traitementPresent();
        tdao.close();

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        AlarmManager.AlarmClockInfo aminfo = am.getNextAlarmClock();
        Calendar cal = Calendar.getInstance();
        Date date = new Date(aminfo.getTriggerTime());
        cal.setTime(date);


        Log.d("++++++++++++++++++++++++++++++++++++++ proch alarme ", cal.toString());

        if(traitement) {
            Intent intent = new Intent(MainActivity.this, ProchaineDateActivity.class);
            finish();
            startActivity(intent);
        }



/*

        final Button dateButton = (Button) findViewById(R.id.bouton);
        dateButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProchaineDateActivity.class);
                finish();
                startActivity(intent);
            }
        });


        final Button newButton = (Button) findViewById(R.id.bouton2);
        newButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewTraitementActivity.class);
                finish();
                startActivity(intent);
            }
        });


        final Button zonebutton = (Button) findViewById(R.id.bouton3);
        zonebutton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ZonesActivity.class);
                finish();
                startActivity(intent);
            }
        });


        ZoneDAO zdao = new ZoneDAO(this);
        zdao.open();



        List<Zone> zones = zdao.getZones();

        for(Zone t : zones) {
            Log.d("zones zzzzzzzzzzzzzzzzzzzzzzz", t.toString());
        }

        zdao.close();

        RappelDAO rdao = new RappelDAO(this);
        rdao.open();
        List<Rappel> rappels = rdao.getRappels();
        rdao.close();

        for(Rappel r : rappels) {
            Log.d("rappels rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr", r.toString());
        }
*/

        /*
        Date javadate = new Date();
        Log.d("dateeeeeeeeeeeeeeeeeeeeeeeeeeeee", javadate.toString());

        java.sql.Date sqlDate = new java.sql.Date(javadate.getTime());
        Log.d("dateeeeeeeeeeeeeeeeeeeeeeeeeeeee sql", sqlDate.toString());
*/

        // DEBUG supprimer tables
/*
        DAOBase dao = new TraitementDAO(this);
        SQLiteDatabase mDb = dao.open();
        DatabaseHandler dh = dao.getmHandler();
        dh.supprimerTables(mDb);
*/



/*
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new java.util.Date());
        cal.add(Calendar.DATE, 10);
        Date newdate = cal.getTime();

        Log.d("-----nouvelle date", "-------------"+newdate);


        Prise prise = new Prise(newdate, t);
        Log.d("nouvelle prochaine date", "------------------"+prise.getTraitement().getDate_renouvellement());
*/




    }

    //menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_about:
                intent = new Intent(MainActivity.this, RessourcesActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_edit:
                intent = new Intent(MainActivity.this, EditerTraitementActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_newtraitement:
                intent = new Intent(MainActivity.this, NewTraitementActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_rappels:
                intent = new Intent(MainActivity.this, SetRappelsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void informations(View view) {
        Intent intent = new Intent(MainActivity.this, RessourcesActivity.class);
        finish();
        startActivity(intent);
    }

    public void nouveauTraitement(View view) {
        Intent intent = new Intent(MainActivity.this, NewTraitementActivity.class);
        finish();
        startActivity(intent);

    }
}
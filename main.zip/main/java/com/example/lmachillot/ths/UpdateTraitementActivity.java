package com.example.lmachillot.ths;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class UpdateTraitementActivity extends AppCompatActivity {

    public static long IDTRAITEMENT=-1;
    Traitement traitement;

    Spinner listehormones, listetypes;
    EditText ednom, eddosage, edfrequence;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_traitement);

        //récupérer variable
        final Intent intent = getIntent();
        IDTRAITEMENT = intent.getLongExtra("IDTRAITEMENT", -1);

        if(IDTRAITEMENT<0) {
            Toast.makeText(this, "pas de traitement associé!", Toast.LENGTH_SHORT).show();
            // redirection
            Intent intent2 = new Intent(UpdateTraitementActivity.this, MainActivity.class);
            finish();
            startActivity(intent2);
        }

        Log.d("############################ ID TRAITEMENT ", IDTRAITEMENT+"");

        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        traitement = tdao.getTraitementParId(IDTRAITEMENT);
        tdao.close();

        Log.d("######################### TRAITEMENT ", traitement.toString());


        // Spinner hormones :

        listehormones = (Spinner) findViewById(R.id.listehormonesupdate);
        int hormone = 0;

        List<String> liste = new ArrayList<>();
        int i=0;
        for (Hormone h : Hormone.values()) {
            liste.add(h.name());
            if(h.name().equals(traitement.getHormone().name())) {
                hormone=i;
            }
            i++;
        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, liste);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listehormones.setAdapter(adapter);
        //pré selectionner hormone du traitement
        listehormones.setSelection(hormone);


        //Spinner type
        listetypes = (Spinner) findViewById(R.id.typeupdate);

        List<String> types = new ArrayList<>();
        int type = 0;
        i=0;
        for (Type t : Type.values()) {
            types.add(t.name());
            if(t.name().equals(traitement.getType().name())) {
                type=i;
            }
            i++;
        }

        ArrayAdapter adaptertype = new ArrayAdapter(this, android.R.layout.simple_spinner_item, types);
        adaptertype.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listetypes.setAdapter(adaptertype);

        //pré selectionner type traitement
        listetypes.setSelection(type);


        //préremplir les champs edittext
        //nom
        ednom = (EditText) findViewById(R.id.nomtraitementupdate);
        ednom.setText(traitement.getNom());

        //dosage
        eddosage = (EditText) findViewById(R.id.dosageupdate);
        eddosage.setText(traitement.getDosage());

        //frequence
        edfrequence = (EditText) findViewById(R.id.freqtraitementupdate);
        edfrequence.setText(traitement.getFrequence()+"");


    }

    public void updateTraitement(View view) {
        String nom = ednom.getText().toString();
        String dosage = eddosage.getText().toString();
        String frequencestr = edfrequence.getText().toString();
        int frequence = Integer.parseInt(frequencestr);
        String hormone = listehormones.getSelectedItem().toString();
        String type = listetypes.getSelectedItem().toString();

        // todo : editer traitement base de donnée

    }

    public void updateZones(View view) {
        updateTraitement(view);

        //todo : activité modifier zones du traitement T
    }
}

package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class PriseDAO extends DAOBase {

    public static String nomtable = "prise";
    public static String ID = "_id";
    public static String  DATE = "dateprise";
    public static String IDTRAITEMENT = "_id_traitement";
    public static String IDZONE = "_id_zone";

    public PriseDAO(Context pContext) {
        super(pContext);
    }


    public long ajouterPrise(Prise p) {
        ContentValues values = new ContentValues();
        values.put(IDTRAITEMENT, p.getTraitement().getId());
        values.put(IDZONE, p.getZone().getId());

        java.sql.Date sqldate = new java.sql.Date(p.getDateprise().getTime());

        values.put(DATE, sqldate.toString());

        long idinsert = mDb.insert(nomtable, null, values);
        //renvoie -1 si pas réussi, id de la ligne insérée sinon

        if(idinsert!=-1)
            p.setId(idinsert);

        return idinsert;

    }

    //DEBUG
    public List<String> getPrisesStr() {
        List<String> liste = new ArrayList<>();

        String requete = "SELECT * FROM "+nomtable;
        Cursor cursor = mDb.rawQuery(requete, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while (cursor.moveToNext()) {
                    Long id = cursor.getLong(0);
                    Long idtraitement = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));
                    Long idzone = cursor.getLong(cursor.getColumnIndex(IDZONE));
                    String datestr = cursor.getString(cursor.getColumnIndex(DATE));

                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date date=null;

                    try {
                        date = format.parse(datestr);
                    } catch (ParseException e) {
                        Log.d("erreur format premieredate traitementDAO", "//////////////////////////////////////");
                        e.printStackTrace();
                    }
                    liste.add("id : "+id+" / date : "+date+" / idtraitement : "+idtraitement+" / idzone : "+idzone);

                }
            }
        }

        return liste;
    }


}

package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by lmachillot on 13/03/17.
 */

public class Rappel {

    private long id;
    private Date daterappel;
    private String mode;

    public Rappel(long id, Date daterappel, String mode) {
        this.id = id;
        this.daterappel = daterappel;
        this.mode=mode;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDaterappel() {
        return daterappel;
    }

    public void setDaterappel(Date daterappel) {
        this.daterappel = daterappel;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "Rappel{" +
                "id=" + id +
                ", daterappel=" + daterappel +
                ", mode='" + mode + '\'' +
                '}';
    }
}

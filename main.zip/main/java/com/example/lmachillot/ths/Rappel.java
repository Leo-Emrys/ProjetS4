package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by lmachillot on 13/03/17.
 */

public class Rappel {

    private long id;
    private String mode;
    private Date daterappel;
    private int heure;
    private int delai;

    public Rappel(long id, String mode, Date daterappel, int heure, int delai) {
        this.id = id;
        this.daterappel = daterappel;
        this.mode=mode;
        this.heure=heure;
        this.delai=delai;
    }

    public int getDelai() {
        return delai;
    }

    public void setDelai(int delai) {
        this.delai = delai;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDaterappel() {
        return daterappel;
    }

    public void setDaterappel(Date daterappel) {
        this.daterappel = daterappel;
    }

    public int getHeure() {
        return heure;
    }

    public void setHeure(int heure) {
        this.heure = heure;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "Rappel{" +
                "id=" + id +
                ", mode='" + mode + '\'' +
                ", daterappel=" + daterappel +
                ", heure=" + heure +
                ", delai=" + delai +
                '}';
    }
}

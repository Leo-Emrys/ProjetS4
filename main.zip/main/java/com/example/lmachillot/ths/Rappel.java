package com.example.lmachillot.ths;

import java.util.Date;

/**
 * Created by lmachillot on 13/03/17.
 */

public class Rappel {

    private long id;
    private String objet;
    private Date daterappel;
    private int heure;
    private int delai;

    public Rappel(long id, String objet, Date daterappel, int heure, int delai) {
        this.id = id;
        this.daterappel = daterappel;
        this.objet=objet;
        this.heure=heure;
        this.delai=delai;
    }

    public int getDelai() {
        return delai;
    }

    public void setDelai(int delai) {
        this.delai = delai;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getDaterappel() {
        return daterappel;
    }

    public void setDaterappel(Date daterappel) {
        this.daterappel = daterappel;
    }

    public int getHeure() {
        return heure;
    }

    public void setHeure(int heure) {
        this.heure = heure;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    @Override
    public String toString() {
        return "Rappel{" +
                "id=" + id +
                ", objet='" + objet + '\'' +
                ", daterappel=" + daterappel +
                ", heure=" + heure +
                ", delai=" + delai +
                '}';
    }
}

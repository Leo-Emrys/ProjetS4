package com.example.lmachillot.ths;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);



    }


    //menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.menu_about:
                intent = new Intent(MenuActivity.this, RessourcesActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_edit:
                intent = new Intent(MenuActivity.this, EditerTraitementActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_newtraitement:
                intent = new Intent(MenuActivity.this, NewTraitementActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_rappels:
                intent = new Intent(MenuActivity.this, SetRappelsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}

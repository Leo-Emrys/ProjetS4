package com.example.lmachillot.ths;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class NewTraitementActivity extends AppCompatActivity {

    Spinner listehormones;
    Spinner listejours;
    Spinner listemois;
    Spinner listetypes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_traitement);


        // Spinner hormones :

        listehormones = (Spinner) findViewById(R.id.listehormones);

        List<String> liste = new ArrayList<String>();
        for(Hormone h : Hormone.values()) {
            liste.add(h.name());
        }

        ArrayAdapter adapter = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                liste
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listehormones.setAdapter(adapter);


        //Spinner jours
        listejours = (Spinner) findViewById(R.id.jourpremprise);

        List<Integer> jours = new ArrayList<Integer>();
        //utilier calendar pour avoir le bon nombre de jours selon le mois.......................
        for(int i=1; i<31; i++) {
            jours.add(i);
        }

        ArrayAdapter adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, jours);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listejours.setAdapter(adapter2);

        //Spinner mois
        listemois = (Spinner) findViewById(R.id.moispremprise);

        List<String> mois = new ArrayList<String>();
        mois.add("Janvier");
        mois.add("Février");
        mois.add("Mars");
        mois.add("Avril");
        mois.add("Mai");
        mois.add("Juin");
        mois.add("Juillet");
        mois.add("Août");
        mois.add("Septembre");
        mois.add("Octobre");
        mois.add("Novembre");
        mois.add("Décembre");

        ArrayAdapter adapter3 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, mois);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listemois.setAdapter(adapter3);

        // ANNEE : mettre l'année courante par def ? cf Calendar


        //Spinner type
        listetypes = (Spinner) findViewById(R.id.type);

        List<String> types = new ArrayList<String>();

        for(Type t : Type.values()) {
            types.add(t.name());
        }

        ArrayAdapter adapter4 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, types);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listetypes.setAdapter(adapter4);


    }


    public void enregistrerTraitement(View view) {
        Log.d("ddddddddddddddddddddddddddddddddd", " ooooh tu as cliqué oO");

        //récupérer données

        EditText ctnom = (EditText) findViewById(R.id.nomtraitement);
        String nomtraitement = ctnom.getText().toString();

        Spinner cthormone = (Spinner) findViewById(R.id.listehormones);
        String hormonestr = cthormone.getSelectedItem().toString();
        Hormone hormone = null;
        for(Hormone h : Hormone.values()) {
            if(h.name().equals(hormonestr)) {
                hormone=h;
            }
        }

        EditText ctfrequence = (EditText) findViewById(R.id.freqtraitement);
        int frequence = Integer.valueOf(ctfrequence.getText().toString());

        Spinner ctjour = (Spinner) findViewById(R.id.jourpremprise);
        int jour = Integer.valueOf(ctjour.getSelectedItem().toString());

        Spinner ctmois = (Spinner) findViewById(R.id.moispremprise);
        int mois = ctmois.getSelectedItemPosition()+1;


        EditText ctannee = (EditText) findViewById(R.id.anneepremprise);
        int annee = Integer.valueOf(ctannee.getText().toString());

        String datestr = annee+"-"+mois+"-"+jour;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {

            date = format.parse(datestr);
            Log.d("format ++", "********************  "+date);
        } catch (ParseException e) {
            Log.d("erreur format", "//////////////////////////////////////");
            e.printStackTrace();
        }


        Spinner cttype = (Spinner) findViewById(R.id.type);
        String typestr = cttype.getSelectedItem().toString();
        Type type = null;
        for(Type t : Type.values()) {
            if(t.name().equals(typestr)) {
                type=t;
            }
        }

        int stock = -1;

        // !!!!!!!!!!!!!! vérifier que c'est bien un nombre
        EditText ctdosage = (EditText) findViewById(R.id.dosage);
        Float dosage = Float.valueOf(ctdosage.getText().toString());

        //créer objet Traitement

        Traitement t = new Traitement(-1, nomtraitement, hormone, frequence, date, null, stock, dosage, type);
        t.calculeDateRenouv();

        Date prochaineDate = t.getDate_renouvellement();
        Log.d("prochaine date calculée ? ", prochaineDate.toString());
        Log.d("Traitement :::::::::: ", t.toString());

        // enregistrer dans BD
        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        tdao.ajouterTraitement(t);

        Log.d("id traitement maj ?", t.getId()+"");

        ArrayList<Traitement> traitements = tdao.getTraitements();

        for(Traitement t1 : traitements) {
            Log.d("ENREGISTRE ``````````````````", t1.toString());
        }


        tdao.close();

        // redirection activité enregistrer zones

        Intent intent = new Intent(NewTraitementActivity.this, ZonesActivity.class);
        startActivity(intent);

    }
}

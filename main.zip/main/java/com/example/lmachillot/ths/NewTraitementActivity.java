package com.example.lmachillot.ths;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class NewTraitementActivity extends AppCompatActivity {

    Spinner listehormones;
    Spinner listejours;
    Spinner listemois;
    Spinner listetypes;

    Context context;

    int moisSelect;
    int annee;
    Calendar cal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_traitement);


        context=this;
        //init calendrier
        cal = Calendar.getInstance();


        // Spinner hormones :

        listehormones = (Spinner) findViewById(R.id.listehormones);

        List<String> liste = new ArrayList<String>();
        for (Hormone h : Hormone.values()) {
            liste.add(h.name());
        }

        ArrayAdapter adapter = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                liste
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listehormones.setAdapter(adapter);


        //Spinner mois
        listemois = (Spinner) findViewById(R.id.moispremprise);
        ArrayAdapter adapter3 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.mois));
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listemois.setAdapter(adapter3);

        moisSelect = cal.get(Calendar.MONTH);
        listemois.setSelection(moisSelect);

        // ANNEE : mettre l'année courante par defaut

        annee = cal.get(Calendar.YEAR);
        String anneestr = annee+"";
        final EditText editannee = (EditText) findViewById(R.id.anneepremprise);
        editannee.setText(anneestr);


        //Spinner jours
        listejours = (Spinner) findViewById(R.id.jourpremprise);

        final List<Integer> jours = new ArrayList<Integer>();

        for (int i = 1; i <= 31; i++) {
            jours.add(i);
        }
        ArrayAdapter adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, jours);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listejours.setAdapter(adapter2);

        int jourcourant = cal.get(Calendar.DAY_OF_MONTH);
        listejours.setSelection(jourcourant-1);

        //utilier calendar pour avoir le bon nombre de jours selon le mois séléctionné (listener pour changer dynamiquement)
        // (ne marche pas..)
/*
        listejours.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("hello +++++++++++++", "onItemSelectd !");
                Spinner ctmois = (Spinner) findViewById(R.id.moispremprise);
                moisSelect = ctmois.getSelectedItemPosition();
                cal.set(annee, moisSelect, 1);
                int nbjours = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

                for (int i1 = 1; i1 < 31; i1++) {
                    jours.add(i1);
                }
                ArrayAdapter adapter2 = new ArrayAdapter(context, android.R.layout.simple_spinner_item, jours);
                adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                listejours.setAdapter(adapter2);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Log.d("salut ---------------------", "onNothingSelectd !");


            }


        });

*/

            //Spinner type
            listetypes = (Spinner) findViewById(R.id.type);

            List<String> types = new ArrayList<String>();

            for (Type t : Type.values()) {
                types.add(t.name());
            }

            ArrayAdapter adapter4 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, types);
            adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            listetypes.setAdapter(adapter4);


    }



    public void enregistrerTraitement(View view) {
        Log.d("ddddddddddddddddddddddddddddddddd", " ooooh tu as cliqué oO");

        //récupérer données

        EditText ctnom = (EditText) findViewById(R.id.nomtraitement);
        String nomtraitement = ctnom.getText().toString();

        Spinner cthormone = (Spinner) findViewById(R.id.listehormones);
        String hormonestr = cthormone.getSelectedItem().toString();
        Hormone hormone = null;
        for(Hormone h : Hormone.values()) {
            if(h.name().equals(hormonestr)) {
                hormone=h;
            }
        }

        EditText ctfrequence = (EditText) findViewById(R.id.freqtraitement);
        int frequence = Integer.valueOf(ctfrequence.getText().toString());

        Spinner ctjour = (Spinner) findViewById(R.id.jourpremprise);
        int jour = Integer.valueOf(ctjour.getSelectedItem().toString());

        Spinner ctmois = (Spinner) findViewById(R.id.moispremprise);
        int mois = ctmois.getSelectedItemPosition()+1;


        EditText ctannee = (EditText) findViewById(R.id.anneepremprise);
        int annee = Integer.valueOf(ctannee.getText().toString());

        String datestr = annee+"-"+mois+"-"+jour;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {

            date = format.parse(datestr);
            Log.d("format ++", "********************  "+date);
        } catch (ParseException e) {
            Log.d("erreur format", "//////////////////////////////////////");
            e.printStackTrace();
        }


        Spinner cttype = (Spinner) findViewById(R.id.type);
        String typestr = cttype.getSelectedItem().toString();
        Type type = null;
        for(Type t : Type.values()) {
            if(t.name().equals(typestr)) {
                type=t;
            }
        }

        int stock = -1;

        // !!!!!!!!!!!!!! vérifier que c'est bien un nombre
        EditText ctdosage = (EditText) findViewById(R.id.dosage);
        Float dosage = Float.valueOf(ctdosage.getText().toString());

        //créer objet Traitement

        Traitement t = new Traitement(-1, nomtraitement, hormone, frequence, date, null, stock, dosage, type);
        t.calculeDateRenouv();

        Date prochaineDate = t.getDate_renouvellement();
        Log.d("prochaine date calculée ? ", prochaineDate.toString());
        Log.d("Traitement :::::::::: ", t.toString());

        // enregistrer dans BD
        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        tdao.ajouterTraitement(t);

        Log.d("id traitement maj ?", t.getId()+"");

        ArrayList<Traitement> traitements = tdao.getTraitements();

        for(Traitement t1 : traitements) {
            Log.d("ENREGISTRE ``````````````````", t1.toString());
        }


        tdao.close();

        // redirection activité enregistrer zones

        Intent intent = new Intent(NewTraitementActivity.this, ZonesActivity.class);
        finish();
        startActivity(intent);

    }
}

package com.example.lmachillot.ths;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class SetRappelsActivity extends MenuActivity {

    public static long IDTRAITEMENT = -1;
    private Traitement traitement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_rappels);



        //récupérer variable idtraitement
        final Intent intent = getIntent();
        IDTRAITEMENT = intent.getLongExtra("IDTRAITEMENT", -1);



        if(IDTRAITEMENT<0) {
            Toast.makeText(this, "pas de traitement associé!", Toast.LENGTH_SHORT).show();
            // redirection ?
            Intent intent2 = new Intent(SetRappelsActivity.this, NewTraitementActivity.class);
            finish();
            startActivity(intent2);
        }

        //récupérer traitement
        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        traitement = tdao.getTraitementParId(IDTRAITEMENT);
        tdao.close();

        if(traitement==null) {
            Log.d("------------------------", "impossible de récupérer le traitement "+IDTRAITEMENT);
            Toast.makeText(this, "Erreur Traitement", Toast.LENGTH_SHORT);
        }

        //afficher nom traitement
        TextView textView = (TextView) findViewById(R.id.traitementrappel);
        textView.setText(" "+traitement.getNom());


    }


    public void passer(View view) {

        //affichage DEBUG
        AlarmeDAO adao = new AlarmeDAO(this);
        adao.open();
        List<String> alarmes = adao.getAlarmes();

        adao.close();

        for(String s : alarmes) {
            Log.d("###################### ALARME :", s);
        }



        ////////////////////////


        Intent intent = new Intent(SetRappelsActivity.this, ProchaineDateActivity.class);
        finish();
        intent.putExtra("IDTRAITEMENT", IDTRAITEMENT);
        startActivityForResult(intent, 0);
    }

    public void recharger() {

        //affichages verif /////////////////////////////////////////////
        RappelDAO rdao = new RappelDAO(this);
        rdao.open();
        List<Rappel> listerappels = rdao.getRappels();
        rdao.close();

        for(Rappel r : listerappels) {
            Log.d("*************** RAPPELS ENREGISTRES", r.toString());
        }



        ////////////////////////////////////////////////////////

        Intent intent = getIntent();
        finish();
        startActivity(intent);

    }

    public Rappel enregistrerRappel(int nbjours, int heure) {
        //récupérer prochaine date traitement
        Date prochainedate = traitement.getDate_renouvellement();


        //soustraire nombre de jours
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(prochainedate);
        cal.add(Calendar.DATE, -nbjours);
        Date daterappel = cal.getTime();

        Log.d("+++++++++++++++++++++++", "Date du prochain rappel : "+daterappel);

        //créer Rappel
        Rappel rappel = new Rappel(-1, "traitement", daterappel, heure, nbjours, IDTRAITEMENT);
        Log.d("nbre de jourrrrrrrrrrrrrrrrrrrrrrrrrrs", nbjours+"");

        //enregistrement BD
        RappelDAO rdao = new RappelDAO(this);
        rdao.open();
        rdao.ajouterRappel(rappel);

        rdao.close();

        return rappel;
    }


    public boolean traitementRappel() {

        boolean ok = true;

        //récupérer champ jours
        EditText ednbjours = (EditText) findViewById(R.id.nbjours);
        String nbjoursstr = ednbjours.getText().toString();
        int nbjours = -1;

        try {
            nbjours = Integer.parseInt(nbjoursstr);
        } catch(Exception e) {
            Toast.makeText(this, "Entrer un nombre de jours", Toast.LENGTH_SHORT).show();
            ok=false;
        }

        if(nbjours==-1) {
            ok=false;
        }

        int heure = -1;

        EditText edheure = (EditText) findViewById(R.id.heurerappel);
        String heurestr = edheure.getText().toString();

        try {
            heure = Integer.parseInt(heurestr);
        } catch(Exception e) {
            Toast.makeText(this, "Entrer une heure (nombre entier)", Toast.LENGTH_SHORT).show();
            ok=false;
        }

        if(heure==-1) {
            ok=false;
        }

        if(ok) {
            // ToDo : verifier si il n'existe pas déjà un rappel à cette date / heure, auquel cas ne pas en créer un nouveau

            enregistrerRappel(nbjours, heure);
        }

        //enregistrer delai dans delaipref (préférences délai pour traitement t)
        DelaiPref dp = new DelaiPref(-1, nbjours, heure, traitement);
        DelaiPrefDAO dpdao = new DelaiPrefDAO(this);
        dpdao.open();
        dpdao.ajouterDelaiPref(dp);
        dpdao.close();

        //affichage DEBUG
        dpdao.open();
        List<String> liste = dpdao.getDelaiPrefStr();
        dpdao.close();

        for (String d : liste) {
            Log.d("++++++++++++++++++++++ DELAI PREF TABLE", d);
        }

        //////////////////////

        return ok;

    }

    public void validerEtContinuer(View view) {

        traitementRappel();



        recharger();
    }


    public void validerTerminer(View view) {

        if(traitementRappel()) {
            passer(view);
        } else {
            recharger();
        }

    }

}

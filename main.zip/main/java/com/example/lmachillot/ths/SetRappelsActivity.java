package com.example.lmachillot.ths;

import android.content.Intent;
import android.graphics.Region;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class SetRappelsActivity extends AppCompatActivity {

    public static String IDTRAITEMENT = "-1";
    private long idt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_rappels);

        //récupérer variable idtraitement
        final Intent intent = getIntent();
        IDTRAITEMENT = intent.getStringExtra(ZonesActivity.IDTRAITEMENT);
        if(IDTRAITEMENT==null || IDTRAITEMENT.length()==0) {
            Toast.makeText(this, "pas de traitement associé!", Toast.LENGTH_SHORT).show();
            // redirection ?
            Intent intent2 = new Intent(SetRappelsActivity.this, NewTraitementActivity.class);
            finish();
            startActivity(intent2);
        }

        //init idtraitement en long
        idt = Long.parseLong(IDTRAITEMENT);


        //récupérer nom traitement pour l'afficher
        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        String nomtraitement = tdao.getNomTraitement(idt);
        tdao.close();

        //afficher nom traitement
        TextView textView = (TextView) findViewById(R.id.traitementrappel);
        textView.setText(" "+nomtraitement);


    }


    public void passer(View view) {
        Intent intent = new Intent(SetRappelsActivity.this, OptionsSupActivity.class);
        finish();
        intent.putExtra(IDTRAITEMENT, IDTRAITEMENT);
        startActivityForResult(intent, 0);
    }

    public void recharger() {

        //affichages verif /////////////////////////////////////////////
        RappelDAO rdao = new RappelDAO(this);
        rdao.open();
        List<Rappel> listerappels = rdao.getRappels();
        rdao.close();

        for(Rappel r : listerappels) {
            Log.d("*************** RAPPELS ENREGISTRES", r.toString());
        }

        TC_TraitementRappelDAO trdao = new TC_TraitementRappelDAO(this);
        trdao.open();
        List<TC_TraitementRappel> listetr = trdao.getTraitementRappels();
        trdao.close();

        for(TC_TraitementRappel tr : listetr) {
            Log.d("***************** TC enregistrements", tr.toString());
        }

        ////////////////////////////////////////////////////////

        Intent intent = getIntent();
        finish();
        startActivity(intent);

    }

    public long enregistrerRappel(int nbjours) {
        //récupérer prochaine date traitement
        TraitementDAO tdao = new TraitementDAO(this);
        tdao.open();
        Date prochainedate = tdao.getProchaineDate(idt);
        tdao.close();


        //soustraire nombre de jours
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(prochainedate);
        cal.add(Calendar.DATE, -nbjours);
        Date daterappel = cal.getTime();

        Log.d("+++++++++++++++++++++++", "Date du prochain rappel : "+daterappel);

        //créer Rappel
        Rappel rappel = new Rappel(-1, daterappel, "notification");

        //enregistrement BD
        RappelDAO rdao = new RappelDAO(this);
        rdao.open();
        long idrappel=rdao.ajouterRappel(rappel);

        rdao.close();

        return idrappel;
    }

    public void enregistrerRappelTraitement(long idrappel) {
        TC_TraitementRappel tr = new TC_TraitementRappel(idt, idrappel);
        TC_TraitementRappelDAO trdao = new TC_TraitementRappelDAO(this);
        trdao.open();
        trdao.ajouterTraitementRappel(tr);

        trdao.close();
    }

    public boolean traitementRappel() {

        boolean ok = true;

        //récupérer champ jours
        EditText ednbjours = (EditText) findViewById(R.id.nbjours);
        String nbjoursstr = ednbjours.getText().toString();
        int nbjours = -1;

        try {
            nbjours = Integer.parseInt(nbjoursstr);
        } catch(Exception e) {
            Toast.makeText(this, "Entrer un nombre", Toast.LENGTH_SHORT).show();
            ok=false;
        }

        if(nbjours==-1) {
            ok=false;
        }

        long idrappel = enregistrerRappel(nbjours);


        enregistrerRappelTraitement(idrappel);
        return ok;

    }

    public void validerEtContinuer(View view) {

        traitementRappel();

        recharger();
    }


    public void validerTerminer(View view) {

        if(traitementRappel()) {
            passer(view);
        } else {
            recharger();
        }

    }

}

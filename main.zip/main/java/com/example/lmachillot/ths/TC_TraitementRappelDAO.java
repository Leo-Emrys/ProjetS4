package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class TC_TraitementRappelDAO extends DAOBase {

    public static String nomtable = "tc_traitement_rappel";
    public static String IDTRAITEMENT = "_id_traitement";
    public static String IDRAPPEL = "_id_rappel";

    public TC_TraitementRappelDAO(Context pContext) {
        super(pContext);
    }

    public long ajouterTraitementRappel(TC_TraitementRappel tr) {
        ContentValues values = new ContentValues();

        values.put(IDRAPPEL, tr.getIdrappel());
        values.put(IDTRAITEMENT, tr.getIdtraitement());

        long id = mDb.insert(nomtable, null, values);

        return id;
    }

    public List<TC_TraitementRappel> getTraitementRappels() {
        List<TC_TraitementRappel> liste = new ArrayList<>();
        String requete = "SELECT * FROM "+nomtable+" ORDER BY "+IDRAPPEL+" DESC LIMIT 50";
        Cursor cursor = mDb.rawQuery(requete, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                while (cursor.moveToNext()) {
                    Long idtraitement = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));
                    Long idrappel = cursor.getLong(cursor.getColumnIndex(IDRAPPEL));
                    TC_TraitementRappel tr = new TC_TraitementRappel(idtraitement, idrappel);
                    liste.add(tr);
                }
            }
        }
        return liste;
    }

}

package com.example.lmachillot.ths;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by lmachillot on 16/03/17.
 */

public class TC_TraitementRappelDAO extends DAOBase {

    public static String nomtable = "tc_traitement_rappel";
    public static String IDTRAITEMENT = "_id_traitement";
    public static String IDRAPPEL = "_id_rappel";

    public TC_TraitementRappelDAO(Context pContext) {
        super(pContext);
    }

    public long ajouterTraitementRappel(TcTraitementRappel tr) {
        ContentValues values = new ContentValues();

        values.put(IDRAPPEL, tr.getRappel().getId());
        values.put(IDTRAITEMENT, tr.getTraitement().getId());

        long id = mDb.insert(nomtable, null, values);

        return id;
    }

    public List<String> getTraitementRappelsStr() {
        List<String> liste = new ArrayList<>();
        String requete = "SELECT * FROM " + nomtable + " ORDER BY " + IDRAPPEL + " DESC LIMIT 50";
        Cursor cursor = mDb.rawQuery(requete, null);

        if (cursor != null) {
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    Long idtraitement = cursor.getLong(cursor.getColumnIndex(IDTRAITEMENT));
                    Long idrappel = cursor.getLong(cursor.getColumnIndex(IDRAPPEL));
                    liste.add("idtraitment : " + idtraitement + " / idrappel : " + idrappel);
                }
            }
            cursor.close();
        }
        return liste;
    }


    private Rappel constrRappelDepuisCurs(Cursor cursor) {
        Rappel rappel = null;

        while (cursor.moveToNext()) {
            long idrappel = cursor.getLong(cursor.getColumnIndex(IDRAPPEL));
            Log.d("idrappel *********************", idrappel + "");
            String objet = cursor.getString(cursor.getColumnIndex(RappelDAO.OBJET));
            String datestr = cursor.getString(cursor.getColumnIndex(RappelDAO.DATE));
            int delai = cursor.getInt(cursor.getColumnIndex(RappelDAO.DELAI));
            int heure = cursor.getInt(cursor.getColumnIndex(RappelDAO.HEURE));

            //convertion date
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date daterappel = null;

            if (datestr != null) {
                try {
                    daterappel = format.parse(datestr);
                } catch (ParseException e) {
                    Log.d("erreur format daterappel TC Traitement RAppel DAO", "//////////////////////////////////////");
                    e.printStackTrace();
                }
            }

            rappel = new Rappel(idrappel, objet, daterappel, heure, delai);

        }


        return rappel;
    }


    public Rappel getDernierRappelTraitement(Traitement t) {
        Rappel rappel = null;
        String req = "SELECT " + IDRAPPEL + ", " + IDTRAITEMENT + ", " +
                RappelDAO.ID + ", " + RappelDAO.OBJET + ", " + RappelDAO.DATE + ", " + RappelDAO.DELAI + ", " + RappelDAO.HEURE +
                " FROM " + nomtable + " INNER JOIN " + RappelDAO.nomtable +
                " ON "+IDRAPPEL+"="+RappelDAO.ID+
                " WHERE " + IDTRAITEMENT + "=" + t.getId() + " AND " + RappelDAO.OBJET + "='traitement'" +
                " ORDER BY " + RappelDAO.ID + " DESC LIMIT 1";
        Cursor cursor = mDb.rawQuery(req, null);

        if (cursor != null) {
            if (cursor.getCount() > 0) {
                rappel = constrRappelDepuisCurs(cursor);

            } else {
                Log.d("---------------------", "pas de result dernier rappel traitement (TC T-R DAO");
            }
            cursor.close();
        }

        return rappel;
    }


    public Rappel getProchainRappelTraitement(Traitement t) {
        Rappel rappel = null;

        Log.d("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "t id"+t.getId());

        Date dateactuelle = new Date();
        java.sql.Date sqldate = new java.sql.Date(dateactuelle.getTime());


        String requete ="SELECT " + IDRAPPEL + ", " + IDTRAITEMENT + ", " +
                RappelDAO.ID + ", " + RappelDAO.OBJET + ", " + RappelDAO.DATE + ", " + RappelDAO.DELAI + ", " + RappelDAO.HEURE +
                " FROM " + nomtable + " INNER JOIN " + RappelDAO.nomtable +
                " ON "+IDRAPPEL+"="+RappelDAO.ID+
                " WHERE "+RappelDAO.DATE+">"+sqldate.toString()+" AND "+IDTRAITEMENT+"="+t.getId()+
                " ORDER BY "+RappelDAO.DATE+" ASC LIMIT 1";

        Cursor cursor = mDb.rawQuery(requete, null);

        if(cursor!=null) {
            if(cursor.getCount()>0) {
                rappel = constrRappelDepuisCurs(cursor);

                cursor.moveToFirst();
                Log.d("7777777777777777777777", cursor.getString(cursor.getColumnIndex(RappelDAO.DATE)));
            } else {
                Log.d("------------------------", "Pas de prochain rappel ?????");
            }

            cursor.close();
        }


        return rappel;

    }
}
